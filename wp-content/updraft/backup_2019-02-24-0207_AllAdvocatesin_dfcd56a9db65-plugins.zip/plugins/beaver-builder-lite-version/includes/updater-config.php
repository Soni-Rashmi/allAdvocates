<?php

if ( class_exists( 'FLUpdater' ) ) {
	FLUpdater::add_product(array(
		'name'      => 'Beaver Builder Plugin (Lite Version)',
		'version'   => '2.1.4.5',
		'slug'      => 'bb-plugin',
		'type'      => 'plugin',
	));
}
