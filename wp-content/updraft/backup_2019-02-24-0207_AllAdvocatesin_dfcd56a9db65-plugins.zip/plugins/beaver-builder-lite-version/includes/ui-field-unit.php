<input
type="number"
name="{{data.name}}"
value="{{{data.value}}}"
placeholder="<# if ( data.field.placeholder ) {  #>{{data.field.placeholder}}<# } #>"
/>
