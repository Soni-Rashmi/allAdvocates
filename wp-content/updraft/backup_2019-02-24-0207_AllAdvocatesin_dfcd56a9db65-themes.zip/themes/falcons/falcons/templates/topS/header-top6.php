<div class="uou-block-1f">
	<div class="container">
    <?php get_template_part('templates/header','language'); ?>
    <?php get_template_part('templates/header','social'); ?>  
    <?php get_search_form(); ?>
    <?php get_template_part('templates/header','login'); ?>  
    </div>
  </div> <!-- end .uou-block-1a -->

