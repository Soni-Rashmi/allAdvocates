  <div class="uou-block-1b">
    <div class="container">
    	<?php get_template_part('templates/header','language'); ?>
    	<?php get_template_part('templates/header','login'); ?>
    	<?php get_template_part('templates/header','social'); ?>

    </div>
  </div> <!-- end .uou-block-1a -->





