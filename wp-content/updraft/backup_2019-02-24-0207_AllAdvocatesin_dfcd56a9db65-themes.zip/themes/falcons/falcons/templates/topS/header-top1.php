      <div class="uou-block-1a">
      <div class="container">

      
      <div class="search">
        <a href="#" class="toggle fa fa-search"></a>
        <?php
          get_search_form();
         ?>
        
      </div> 
        <?php get_template_part('templates/header','top'); ?> 
    </div>
  </div> <!-- end .uou-block-1a -->
