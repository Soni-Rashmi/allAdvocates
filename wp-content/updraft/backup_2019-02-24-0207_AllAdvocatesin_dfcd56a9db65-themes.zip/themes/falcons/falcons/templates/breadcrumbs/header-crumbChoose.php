<?php $falcons_option_data =get_option('falcons_option_data');  ?>

 <?php if(isset($falcons_option_data['falcons-breadcrumb-switch']) && ($falcons_option_data['falcons-breadcrumb-switch']==1)){?>

        <?php if(isset($falcons_option_data['falcons-multi-breadcrumb-image'])&&($falcons_option_data['falcons-multi-breadcrumb-image']==1)){?> 
        
                <?php get_template_part('templates/breadcrumbs/header','bc1'); ?>
        <?php } ?>

        <?php if(isset($falcons_option_data['falcons-multi-breadcrumb-image'])&&($falcons_option_data['falcons-multi-breadcrumb-image']==2)){?>  
               
                <?php get_template_part('templates/breadcrumbs/header','bc2'); ?>
 
        <?php } ?>

        <?php if(isset($falcons_option_data['falcons-multi-breadcrumb-image'])&&($falcons_option_data['falcons-multi-breadcrumb-image']==3)){?>   
                <?php get_template_part('templates/breadcrumbs/header','bc3'); ?>
 
        <?php } ?>
 
        <?php if(isset($falcons_option_data['falcons-multi-breadcrumb-image'])&&($falcons_option_data['falcons-multi-breadcrumb-image']==4)){?>   
                <?php get_template_part('templates/breadcrumbs/header','bc4'); ?>
 
        <?php } ?>

        <?php if(isset($falcons_option_data['falcons-multi-breadcrumb-image'])&&($falcons_option_data['falcons-multi-breadcrumb-image']==5)){?>   
        
                <?php get_template_part('templates/breadcrumbs/header','bc5'); ?>

        <?php } ?>

        <?php if(isset($falcons_option_data['falcons-multi-breadcrumb-image'])&&($falcons_option_data['falcons-multi-breadcrumb-image']==6)){?>   
                <?php get_template_part('templates/breadcrumbs/header','bc6'); ?>

        <?php } ?>

        <?php if(isset($falcons_option_data['falcons-multi-breadcrumb-image'])&&($falcons_option_data['falcons-multi-breadcrumb-image']==7)){?>   
                <?php get_template_part('templates/breadcrumbs/header','bc7'); ?>

        <?php } ?>

        <?php if(isset($falcons_option_data['falcons-multi-breadcrumb-image'])&&($falcons_option_data['falcons-multi-breadcrumb-image']==8)){?>   
        
                <?php get_template_part('templates/breadcrumbs/header','bc8'); ?>

        <?php } ?>

        <?php if(isset($falcons_option_data['falcons-multi-breadcrumb-image'])&&($falcons_option_data['falcons-multi-breadcrumb-image']==9)){?>   
                <?php get_template_part('templates/breadcrumbs/header','bc9'); ?>

        <?php } ?>

        <?php if(isset($falcons_option_data['falcons-multi-breadcrumb-image'])&&($falcons_option_data['falcons-multi-breadcrumb-image']==10)){?>   
                <?php get_template_part('templates/breadcrumbs/header','bc10'); ?>

        <?php } ?>

        <?php if(isset($falcons_option_data['falcons-multi-breadcrumb-image'])&&($falcons_option_data['falcons-multi-breadcrumb-image']==11)){?>   

                <?php get_template_part('templates/breadcrumbs/header','bc11'); ?>

        <?php } ?>

        <?php if(isset($falcons_option_data['falcons-multi-breadcrumb-image'])&&($falcons_option_data['falcons-multi-breadcrumb-image']==12)){?>   
        
                <?php get_template_part('templates/breadcrumbs/header','bc12'); ?>

        <?php } ?>
        <?php if(isset($falcons_option_data['falcons-multi-breadcrumb-image'])&&($falcons_option_data['falcons-multi-breadcrumb-image']==13)){?>   
                <?php get_template_part('templates/breadcrumbs/header','bc13'); ?>

        <?php } ?>
        <?php if(isset($falcons_option_data['falcons-multi-breadcrumb-image'])&&($falcons_option_data['falcons-multi-breadcrumb-image']==14)){?>   
        
                <?php get_template_part('templates/breadcrumbs/header','bc14'); ?>

        <?php } ?>
        <?php if(isset($falcons_option_data['falcons-multi-breadcrumb-image'])&&($falcons_option_data['falcons-multi-breadcrumb-image']==15)){?>   
         
                <?php get_template_part('templates/breadcrumbs/header','bc15'); ?>

        <?php } ?>
        <?php if(isset($falcons_option_data['falcons-multi-breadcrumb-image'])&&($falcons_option_data['falcons-multi-breadcrumb-image']==16)){?>   
                <?php get_template_part('templates/breadcrumbs/header','bc16'); ?>

        <?php } ?>
<?php } ?>
