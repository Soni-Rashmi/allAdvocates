  <div class="uou-block-3d secondary">
    <div class="container">
      <ul class="breadcrumbs-secondary">
        <!-- <li> -->
          <?php if (function_exists("falcons_arrow_breadcrumb")) {
                  falcons_arrow_breadcrumb();
                } 
          ?>  
        <!-- </li> -->
      </ul>
      <div class="contact">
        <span>Call Us:</span>
        <a href="tel:(02)1234567890">(02) 123-456-7890</a>
      </div>
    </div>
  </div> <!-- end .uou-block-3b -->